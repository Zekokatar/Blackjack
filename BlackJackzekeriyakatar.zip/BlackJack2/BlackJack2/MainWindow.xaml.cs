﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BlackJack2
{
    namespace Blackjack
    {
        class Program
        {
            static void Main(string[] args)
            {
                // Create a new deck of cards
                List<string> deck = new List<string>() { "Ace of Spades", "Two of Spades", "Three of Spades", "Four of Spades", "Five of Spades", "Six of Spades", "Seven of Spades", "Eight of Spades", "Nine of Spades", "Ten of Spades", "Jack of Spades", "Queen of Spades", "King of Spades",
                                                    "Ace of Hearts", "Two of Hearts", "Three of Hearts", "Four of Hearts", "Five of Hearts", "Six of Hearts", "Seven of Hearts", "Eight of Hearts", "Nine of Hearts", "Ten of Hearts", "Jack of Hearts", "Queen of Hearts", "King of Hearts",
                                                    "Ace of Diamonds", "Two of Diamonds", "Three of Diamonds", "Four of Diamonds", "Five of Diamonds", "Six of Diamonds", "Seven of Diamonds", "Eight of Diamonds", "Nine of Diamonds", "Ten of Diamonds", "Jack of Diamonds", "Queen of Diamonds", "King of Diamonds",
                                                    "Ace of Clubs", "Two of Clubs", "Three of Clubs", "Four of Clubs", "Five of Clubs", "Six of Clubs", "Seven of Clubs", "Eight of Clubs", "Nine of Clubs", "Ten of Clubs", "Jack of Clubs", "Queen of Clubs", "King of Clubs" };

                // Shuffle the deck
                Random rng = new Random();
                int n = deck.Count;
                while (n > 1)
                {
                    n--;
                    int k = rng.Next(n + 1);
                    string value = deck[k];
                    deck[k] = deck[n];
                    deck[n] = value;
                }

                // Deal two cards to the player and the dealer
                List<string> playerHand = new List<string>() { deck[0], deck[2] };
                List<string> dealerHand = new List<string>() { deck[1], deck[3] };

                // Calculate the player's score
                int playerScore = 0;
                foreach (string card in playerHand)
                {
                    if (card.StartsWith("Ace"))
                    {
                        playerScore += 11;
                    }
                    else if (card.StartsWith("Two"))
                    {
                        playerScore += 2;
                    }
                    else if (card.StartsWith("Three"))
                    {
                        playerScore += 3;
                    }
                    else if (card.StartsWith("Four"))
                    {
                        playerScore += 4;
                    }
                    else if (card.StartsWith("Five"))
                    {
                        playerScore += 5;
                    }
                    else if (card.StartsWith("Six"))
                    {
                        playerScore += 6;
                    }
                    else if (card.StartsWith("Seven"))
                    {
                        playerScore += 7;
                    }
                    else if (card.StartsWith("Eight"))
                    {


                    }
